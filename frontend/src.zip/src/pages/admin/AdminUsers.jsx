import React, { useMemo, useState } from 'react';
import AdminSidebar from '../../layout/admin/AdminSidebar';
import {
  Search,
  MoreVertical,
  Eye,
  Lock,
  Unlock,
  ChevronLeft,
  ChevronRight,
  X,
} from 'lucide-react';

const mockUsers = [
  {
    id: 1,
    name: 'Nguyễn Văn An',
    email: 'nguyenvanan@gmail.com',
    goals: ['TOPIK 4', 'Giao tiếp'],
    status: 'active',
    progress: 72,
    joinedAt: '12/09/2026',
  },
  {
    id: 2,
    name: 'Trần Thị Mai',
    email: 'tranthimai@gmail.com',
    goals: ['TOPIK 3'],
    status: 'active',
    progress: 58,
    joinedAt: '10/09/2026',
  },
  {
    id: 3,
    name: 'Lê Minh Đức',
    email: 'leminhduc@gmail.com',
    goals: ['Giao tiếp'],
    status: 'active',
    progress: 45,
    joinedAt: '08/09/2026',
  },
  {
    id: 4,
    name: 'Phạm Hoàng Nam',
    email: 'phamhoangnam@gmail.com',
    goals: ['TOPIK 5'],
    status: 'locked',
    progress: 81,
    joinedAt: '05/09/2026',
  },
  {
    id: 5,
    name: 'Nguyễn Thùy Linh',
    email: 'nguyenthuylinh@gmail.com',
    goals: ['TOPIK 4', 'Giao tiếp'],
    status: 'active',
    progress: 64,
    joinedAt: '03/09/2026',
  },
  {
    id: 6,
    name: 'Đỗ Quốc Huy',
    email: 'doquochuy@gmail.com',
    goals: ['TOPIK 3', 'Giao tiếp'],
    status: 'active',
    progress: 37,
    joinedAt: '01/09/2026',
  },
];

const goalOptions = [
  'TOPIK 3',
  'TOPIK 4',
  'TOPIK 5',
  'Giao tiếp',
];

function StatusBadge({ status }) {
  if (status === 'locked') {
    return (
      <span className="inline-flex items-center px-2 py-1 rounded-lg bg-red-50 text-red-700 text-[11px] font-semibold">
        Đã khóa
      </span>
    );
  }

  return (
    <span className="inline-flex items-center px-2 py-1 rounded-lg bg-emerald-50 text-emerald-700 text-[11px] font-semibold">
      Hoạt động
    </span>
  );
}

function GoalBadge({ goal }) {
  return (
    <span className="inline-flex items-center px-2 py-1 rounded-lg bg-gray-100 text-gray-700 text-[11px] font-medium">
      {goal}
    </span>
  );
}

function ProgressBar({ progress }) {
  return (
    <div className="w-28">
      <div className="flex items-center justify-between mb-1">
        <span className="text-[11px] font-semibold text-gray-700">
          {progress}%
        </span>
      </div>

      <div className="w-full h-1.5 bg-gray-100 rounded-full overflow-hidden">
        <div
          className="h-full bg-emerald-700 rounded-full"
          style={{ width: `${progress}%` }}
        />
      </div>
    </div>
  );
}

function SummaryCard({ label, value, description }) {
  return (
    <div className="bg-white border border-gray-100 rounded-2xl p-5 shadow-sm">
      <p className="text-xs font-medium text-gray-500">
        {label}
      </p>

      <div className="flex items-end justify-between mt-2">
        <h3 className="text-2xl font-black text-gray-900">
          {value}
        </h3>

        <span className="text-[10px] font-medium text-gray-400">
          {description}
        </span>
      </div>
    </div>
  );
}

function UserDetailModal({ user, onClose }) {
  if (!user) {
    return null;
  }

  return (
    <div className="fixed inset-0 z-50 bg-black/30 flex items-center justify-center p-4">
      <div className="bg-white w-full max-w-lg rounded-2xl shadow-xl">
        <div className="flex items-center justify-between p-5 border-b border-gray-100">
          <div>
            <h2 className="text-lg font-bold text-gray-900">
              Thông tin học viên
            </h2>

            <p className="text-xs text-gray-500 mt-1">
              Chi tiết tài khoản và quá trình học tập
            </p>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-lg text-gray-400 hover:text-gray-700 hover:bg-gray-50"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-5 space-y-5">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-full bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold">
              {user.name.charAt(0)}
            </div>

            <div>
              <h3 className="font-bold text-gray-900">
                {user.name}
              </h3>

              <p className="text-xs text-gray-500">
                {user.email}
              </p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="bg-gray-50 rounded-xl p-4">
              <p className="text-[11px] text-gray-500 mb-2">
                Trạng thái
              </p>

              <StatusBadge status={user.status} />
            </div>

            <div className="bg-gray-50 rounded-xl p-4">
              <p className="text-[11px] text-gray-500 mb-2">
                Ngày tham gia
              </p>

              <p className="text-sm font-semibold text-gray-800">
                {user.joinedAt}
              </p>
            </div>
          </div>

          <div>
            <p className="text-xs font-semibold text-gray-700 mb-2">
              Mục tiêu học tập
            </p>

            <div className="flex flex-wrap gap-2">
              {user.goals.map((goal) => (
                <GoalBadge key={goal} goal={goal} />
              ))}
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-2">
              <p className="text-xs font-semibold text-gray-700">
                Tiến độ học tập
              </p>

              <span className="text-sm font-bold text-emerald-700">
                {user.progress}%
              </span>
            </div>

            <div className="w-full h-2 bg-gray-100 rounded-full overflow-hidden">
              <div
                className="h-full bg-emerald-700 rounded-full"
                style={{ width: `${user.progress}%` }}
              />
            </div>
          </div>
        </div>

        <div className="flex justify-end p-5 border-t border-gray-100">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-gray-100 text-gray-700 text-sm font-semibold hover:bg-gray-200"
          >
            Đóng
          </button>
        </div>
      </div>
    </div>
  );
}

function UserActionModal({ user, action, onClose, onConfirm }) {
  if (!user || !action) {
    return null;
  }

  const isLock = action === 'lock';

  return (
    <div className="fixed inset-0 z-50 bg-black/30 flex items-center justify-center p-4">
      <div className="bg-white w-full max-w-md rounded-2xl shadow-xl">
        <div className="p-5">
          <div
            className={`w-10 h-10 rounded-xl flex items-center justify-center mb-4 ${
              isLock
                ? 'bg-red-50 text-red-600'
                : 'bg-emerald-50 text-emerald-700'
            }`}
          >
            {isLock ? (
              <Lock className="w-5 h-5" />
            ) : (
              <Unlock className="w-5 h-5" />
            )}
          </div>

          <h2 className="text-lg font-bold text-gray-900">
            {isLock ? 'Khóa tài khoản?' : 'Mở khóa tài khoản?'}
          </h2>

          <p className="text-sm text-gray-500 mt-2 leading-relaxed">
            {isLock
              ? `Bạn có chắc muốn khóa tài khoản của ${user.name}?`
              : `Bạn có chắc muốn mở khóa tài khoản của ${user.name}?`}
          </p>
        </div>

        <div className="flex justify-end gap-2 p-5 border-t border-gray-100">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-gray-100 text-gray-700 text-sm font-semibold hover:bg-gray-200"
          >
            Hủy
          </button>

          <button
            onClick={onConfirm}
            className={`px-4 py-2 rounded-xl text-white text-sm font-semibold ${
              isLock
                ? 'bg-red-600 hover:bg-red-700'
                : 'bg-emerald-800 hover:bg-emerald-900'
            }`}
          >
            {isLock ? 'Khóa tài khoản' : 'Mở khóa'}
          </button>
        </div>
      </div>
    </div>
  );
}

export default function AdminUsers() {
  const [users, setUsers] = useState(mockUsers);

  const [search, setSearch] = useState('');
  const [goalFilter, setGoalFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');

  const [selectedUser, setSelectedUser] = useState(null);
  const [actionUser, setActionUser] = useState(null);
  const [actionType, setActionType] = useState(null);

  const filteredUsers = useMemo(() => {
    const keyword = search.trim().toLowerCase();

    return users.filter((user) => {
      const matchesSearch =
        keyword === '' ||
        user.name.toLowerCase().includes(keyword) ||
        user.email.toLowerCase().includes(keyword);

      const matchesGoal =
        goalFilter === 'all' ||
        user.goals.includes(goalFilter);

      const matchesStatus =
        statusFilter === 'all' ||
        user.status === statusFilter;

      return matchesSearch && matchesGoal && matchesStatus;
    });
  }, [users, search, goalFilter, statusFilter]);

  const totalUsers = users.length;
  const activeUsers = users.filter(
    (user) => user.status === 'active'
  ).length;
  const lockedUsers = users.filter(
    (user) => user.status === 'locked'
  ).length;
  const learningUsers = users.filter(
    (user) => user.progress > 0
  ).length;

  const handleAction = (user, action) => {
    setActionUser(user);
    setActionType(action);
  };

  const handleConfirmAction = () => {
    if (!actionUser || !actionType) {
      return;
    }

    setUsers((currentUsers) =>
      currentUsers.map((user) => {
        if (user.id !== actionUser.id) {
          return user;
        }

        return {
          ...user,
          status:
            actionType === 'lock'
              ? 'locked'
              : 'active',
        };
      })
    );

    setActionUser(null);
    setActionType(null);
  };

  return (
    <div className="flex bg-gray-50/60 min-h-screen">
      <AdminSidebar activePage="users" />

      <main className="flex-1 p-8 overflow-y-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-2xl font-black text-gray-900">
            Người dùng
          </h1>

          <p className="text-xs text-gray-500 mt-1">
            Quản lý tài khoản và theo dõi hoạt động học tập của học viên.
          </p>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4 mb-6">
          <SummaryCard
            label="Tổng học viên"
            value={totalUsers}
            description="Tài khoản"
          />

          <SummaryCard
            label="Đang hoạt động"
            value={activeUsers}
            description="Hiện tại"
          />

          <SummaryCard
            label="Đã khóa"
            value={lockedUsers}
            description="Tài khoản"
          />

          <SummaryCard
            label="Đang học"
            value={learningUsers}
            description="Có tiến độ"
          />
        </div>

        {/* Search & Filters */}
        <div className="bg-white border border-gray-100 rounded-2xl p-4 shadow-sm mb-6">
          <div className="flex flex-col lg:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />

              <input
                type="text"
                value={search}
                onChange={(event) => setSearch(event.target.value)}
                placeholder="Tìm theo tên hoặc email..."
                className="w-full pl-10 pr-4 py-2.5 border border-gray-200 rounded-xl text-sm outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100"
              />
            </div>

            <select
              value={goalFilter}
              onChange={(event) => setGoalFilter(event.target.value)}
              className="lg:w-44 px-3 py-2.5 border border-gray-200 rounded-xl text-sm text-gray-700 outline-none focus:border-emerald-500"
            >
              <option value="all">Tất cả mục tiêu</option>

              {goalOptions.map((goal) => (
                <option key={goal} value={goal}>
                  {goal}
                </option>
              ))}
            </select>

            <select
              value={statusFilter}
              onChange={(event) => setStatusFilter(event.target.value)}
              className="lg:w-40 px-3 py-2.5 border border-gray-200 rounded-xl text-sm text-gray-700 outline-none focus:border-emerald-500"
            >
              <option value="all">Tất cả trạng thái</option>
              <option value="active">Hoạt động</option>
              <option value="locked">Đã khóa</option>
            </select>
          </div>
        </div>

        {/* User Table */}
        <div className="bg-white border border-gray-100 rounded-2xl shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="bg-gray-50/80 border-b border-gray-100">
                  <th className="text-left px-5 py-3 text-[11px] font-bold text-gray-500 uppercase tracking-wide">
                    Học viên
                  </th>

                  <th className="text-left px-5 py-3 text-[11px] font-bold text-gray-500 uppercase tracking-wide">
                    Mục tiêu
                  </th>

                  <th className="text-left px-5 py-3 text-[11px] font-bold text-gray-500 uppercase tracking-wide">
                    Trạng thái
                  </th>

                  <th className="text-left px-5 py-3 text-[11px] font-bold text-gray-500 uppercase tracking-wide">
                    Tiến độ
                  </th>

                  <th className="text-left px-5 py-3 text-[11px] font-bold text-gray-500 uppercase tracking-wide">
                    Ngày tham gia
                  </th>

                  <th className="text-right px-5 py-3 text-[11px] font-bold text-gray-500 uppercase tracking-wide">
                    Thao tác
                  </th>
                </tr>
              </thead>

              <tbody>
                {filteredUsers.length === 0 ? (
                  <tr>
                    <td
                      colSpan="6"
                      className="px-5 py-16 text-center"
                    >
                      <div className="text-sm font-semibold text-gray-700">
                        Không tìm thấy học viên
                      </div>

                      <p className="text-xs text-gray-400 mt-1">
                        Thử thay đổi từ khóa hoặc bộ lọc.
                      </p>
                    </td>
                  </tr>
                ) : (
                  filteredUsers.map((user) => (
                    <tr
                      key={user.id}
                      className="border-b border-gray-100 last:border-b-0 hover:bg-gray-50/50"
                    >
                      {/* User */}
                      <td className="px-5 py-4">
                        <div className="flex items-center gap-3">
                          <div className="w-9 h-9 rounded-full bg-emerald-100 text-emerald-800 flex items-center justify-center text-xs font-bold">
                            {user.name.charAt(0)}
                          </div>

                          <div>
                            <p className="text-sm font-semibold text-gray-900">
                              {user.name}
                            </p>

                            <p className="text-xs text-gray-500 mt-0.5">
                              {user.email}
                            </p>
                          </div>
                        </div>
                      </td>

                      {/* Goals */}
                      <td className="px-5 py-4">
                        <div className="flex flex-wrap gap-1.5 max-w-52">
                          {user.goals.map((goal) => (
                            <GoalBadge
                              key={goal}
                              goal={goal}
                            />
                          ))}
                        </div>
                      </td>

                      {/* Status */}
                      <td className="px-5 py-4">
                        <StatusBadge status={user.status} />
                      </td>

                      {/* Progress */}
                      <td className="px-5 py-4">
                        <ProgressBar progress={user.progress} />
                      </td>

                      {/* Joined */}
                      <td className="px-5 py-4">
                        <span className="text-xs text-gray-600">
                          {user.joinedAt}
                        </span>
                      </td>

                      {/* Actions */}
                      <td className="px-5 py-4">
                        <div className="flex items-center justify-end gap-1">
                          <button
                            onClick={() => setSelectedUser(user)}
                            className="p-2 rounded-lg text-gray-400 hover:text-emerald-700 hover:bg-emerald-50"
                            title="Xem chi tiết"
                          >
                            <Eye className="w-4 h-4" />
                          </button>

                          <div className="relative group">
                            <button
                              className="p-2 rounded-lg text-gray-400 hover:text-gray-700 hover:bg-gray-100"
                              title="Thao tác"
                            >
                              <MoreVertical className="w-4 h-4" />
                            </button>

                            <div className="hidden group-hover:block absolute right-0 top-full mt-1 w-40 bg-white border border-gray-100 rounded-xl shadow-lg z-20 py-1">
                              <button
                                onClick={() =>
                                  setSelectedUser(user)
                                }
                                className="w-full flex items-center gap-2 px-3 py-2 text-xs text-gray-700 hover:bg-gray-50"
                              >
                                <Eye className="w-3.5 h-3.5" />
                                Xem chi tiết
                              </button>

                              {user.status === 'active' ? (
                                <button
                                  onClick={() =>
                                    handleAction(user, 'lock')
                                  }
                                  className="w-full flex items-center gap-2 px-3 py-2 text-xs text-red-600 hover:bg-red-50"
                                >
                                  <Lock className="w-3.5 h-3.5" />
                                  Khóa tài khoản
                                </button>
                              ) : (
                                <button
                                  onClick={() =>
                                    handleAction(user, 'unlock')
                                  }
                                  className="w-full flex items-center gap-2 px-3 py-2 text-xs text-emerald-700 hover:bg-emerald-50"
                                >
                                  <Unlock className="w-3.5 h-3.5" />
                                  Mở khóa
                                </button>
                              )}
                            </div>
                          </div>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>

          {/* Pagination */}
          <div className="flex items-center justify-between px-5 py-4 border-t border-gray-100">
            <p className="text-xs text-gray-500">
              Hiển thị{' '}
              <span className="font-semibold text-gray-700">
                {filteredUsers.length}
              </span>{' '}
              học viên
            </p>

            <div className="flex items-center gap-1">
              <button
                className="p-2 rounded-lg border border-gray-200 text-gray-400 hover:bg-gray-50"
                disabled
              >
                <ChevronLeft className="w-4 h-4" />
              </button>

              <button className="w-8 h-8 rounded-lg bg-emerald-800 text-white text-xs font-semibold">
                1
              </button>

              <button className="w-8 h-8 rounded-lg text-gray-500 text-xs hover:bg-gray-50">
                2
              </button>

              <button className="p-2 rounded-lg border border-gray-200 text-gray-500 hover:bg-gray-50">
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </main>

      {/* Detail Modal */}
      <UserDetailModal
        user={selectedUser}
        onClose={() => setSelectedUser(null)}
      />

      {/* Lock / Unlock Modal */}
      <UserActionModal
        user={actionUser}
        action={actionType}
        onClose={() => {
          setActionUser(null);
          setActionType(null);
        }}
        onConfirm={handleConfirmAction}
      />
    </div>
  );
}